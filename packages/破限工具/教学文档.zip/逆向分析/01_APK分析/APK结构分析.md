# xTun APK 结构分析

> 文档日期: 2026-09-16
> 状态: ✅ 完成

---

## 1. 应用基本信息

| 属性 | 值 |
|------|-----|
| 应用名称 | xTun |
| 包名 | com.xtun |
| 版本 | 1.0.9 |
| 架构 | Flutter (Dart UI) + Go (核心逻辑) |
| 平台 | Android / Windows |
| API域名 | api.xtun.link |
| 客户端域名 | xtun.link |

## 2. Flutter + Go 架构

xTun 采用 **Flutter + Go 混合架构**：

- **Flutter (Dart)**: 负责UI渲染、用户交互、API HTTP请求
- **Go**: 负责核心VPN逻辑、加密解密、隧道管理、cftun协议实现

### 架构图

```
┌─────────────────────────────────┐
│         Flutter (Dart)           │
│  ┌─────────┐  ┌──────────────┐  │
│  │  UI层   │  │  API请求层   │  │
│  └─────────┘  └──────────────┘  │
│           │ FFI / IPC            │
├───────────┼──────────────────────┤
│         Go (cftun)               │
│  ┌─────────┐  ┌──────────────┐  │
│  │ 加密层  │  │  隧道管理    │  │
│  │X25519   │  │  WebSocket   │  │
│  │AES-GCM  │  │  cftun v3    │  │
│  └─────────┘  └──────────────┘  │
└─────────────────────────────────┘
```

### 通信方式

- **Flutter → Go**: FFI (Android) / IPC named pipe (Windows)
- **Go → 服务器**: WebSocket (cftun WebSocket v3 协议)
- **Flutter → API**: HTTPS REST API

## 3. Go 二进制信息

| 属性 | 值 |
|------|-----|
| 文件名 | xtun-windows.exe |
| 格式 | PE64 (Windows) |
| 大小 | 50,043,240 bytes (~50MB) |
| Go版本 | 1.25.0 |
| Go模块 | github.com/fmnx/cftun/backend@v0.0.0 |
| 基地址 | 0x140000000 |
| 编译器 | Go gc compiler |

## 4. Windows 服务架构

| 进程 | 参数 | 说明 |
|------|------|------|
| xtun-windows.exe | /managerservice | CFTunManager Windows服务 (session 0) |
| xtun-windows.exe | /ui | GUI客户端 (console session) |

本地API端口: 19770

## 5. 关键文件清单

### 二进制文件
| 文件 | 大小 | 说明 |
|------|------|------|
| xtun-windows.exe | 50MB | Go PE64二进制，核心逻辑 |

### 客户端配置
| 路径 | 说明 |
|------|------|
| C:\Users\Administrator\AppData\Local\xTun\user.json | 客户端配置 (含token、节点配置) |

## 6. 权限 (Android)

基于Flutter VPN应用的标准权限需求：
- INTERNET (网络访问)
- BIND_VPN_SERVICE (VPN隧道)
- FOREGROUND_SERVICE (后台服务)
- WAKE_LOCK (保持运行)

## 7. 交叉引用

- [项目概述](../00_项目概述/项目概述.md)
- [Go二进制信息](../03_Go二进制分析/Go二进制信息.md)
- [函数地址与模块](../03_Go二进制分析/函数地址与模块.md)
