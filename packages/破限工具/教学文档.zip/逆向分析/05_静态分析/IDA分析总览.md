# IDA / Capstone 分析总览

> 文档日期: 2026-09-16
> 状态: ✅ 完成
> 数据来源: ida_decompile_summary.md, ida_decompiled.json, capstone_disasm.json

---

## 1. 分析工具信息

| 属性 | 值 |
|------|-----|
| 主分析工具 | Capstone 5.0.7 + pefile |
| 辅助工具 | IDA Pro 8.3 (50MB Go二进制分析耗时较长) |
| 目标二进制 | xtun-windows.exe (Go PE64, 50MB) |
| 基地址 | 0x140000000 |
| Go模块 | github.com/fmnx/cftun |

## 2. 输出文件

| 文件 | 大小 | 说明 |
|------|------|------|
| ida_decompiled.json | 7,261 bytes | IDA/Capstone反编译结果 |
| capstone_disasm.json | 969,111 bytes | Capstone反汇编数据 |
| ida_decompile_summary.md | - | IDA反编译摘要 |

## 3. 核心发现

### 3.1 decryptAccessPoint (0x140365f60)

Capstone反汇编完整覆盖了decryptAccessPoint函数，确认以下参数：

| 参数 | Capstone结果 | 说明 |
|------|-------------|------|
| 算法 | AES-256-GCM | 确认 |
| AAD | "cftun-txt" (9字节) | 确认 |
| 密钥长度 | 32字节 | 确认 |
| Nonce长度 | 12字节 | 确认 |
| Tag长度 | 16字节 | 确认 |
| 密钥派生 | 直接复制(无KDF) | 确认 |
| 解密调用 | GCM.Open @ 0x14036628b | 确认 |
| 后处理 | decodeTXTBinaryPayload | 确认 |

### 3.2 AAD位置 (Capstone确认)

```
0x14036622c: movabs rdi, 0x78742d6e75746663  → "cftun-tx" (前8字节)
0x140366239: mov byte ptr [rax + 8], 0x74    → 't' (第9字节)
0x14036625c: mov qword ptr [rsp + 0x20], 9   → AAD长度=9
```

### 3.3 密钥准备函数 sub_5ac80

```
地址: 0x14005ac80
行为:
  if rax != 0 && rcx <= 0x20:
    zero 32 bytes at [rax]     // movups [rax], xmm15; movups [rax+0x10], xmm15
    copy key material           // memmove to buffer
  else:
    allocate buffer             // call 0x14005b140
    copy key material
输出: 32字节AES-256密钥缓冲区
```

### 3.4 GCM创建函数

```
地址: 0x14016de80 (cipher.NewGCM)
正常路径:
  mov ecx, 0xc    // nonce_size = 12
  mov edi, 0x10   // tag_size = 16
  call 0x14016df20  // 创建GCM上下文
```

## 4. 交叉验证结果

### Ghidra vs Capstone 对比

| 项目 | Ghidra结果 | Capstone结果 | 一致性 |
|------|-----------|-------------|--------|
| 算法 | AES-256-GCM | AES-256-GCM | ✅ 一致 |
| AAD | "cftun-txt" (9字节) | "cftun-txt" (9字节) | ✅ 一致 |
| 密钥长度 | 32字节 | 32字节 | ✅ 一致 |
| Nonce长度 | 12字节 | 12字节 | ✅ 一致 |
| Tag长度 | 16字节 | 16字节 | ✅ 一致 |
| 密钥派生 | SHA256(无额外KDF) | 直接复制(无KDF) | ✅ 一致 |
| 解密调用 | aead.Open | GCM.Open @ 0x14036628b | ✅ 一致 |
| 后处理 | decodeTXTBinaryPayload | decodeTXTBinaryPayload | ✅ 一致 |

**结论**: 两种工具的分析结果完全一致，加密参数可信度极高。

## 5. 关键字符串 (Capstone确认)

| 字符串 | VA | 用途 |
|--------|-----|------|
| cftun-txt | 0x14036622c (内联) | AES-GCM AAD |
| cftun-config-response-v1 | 0x1404eb1f1 | 配置响应类型 |
| invalid encrypted access point | 0x14074f766 | 错误消息 |
| authenticatedAccessPointPayload | 0x142a22dcf | 认证载荷函数名 |
| decryptAccessPoint | 0x2a52802 | Go函数名 |
| crypto/aes | 0x1405c153f | AES加密包 |
| AES_GCM_NoPadding | 0x140f6f1c0 | GCM模式标识 |

## 6. IDA Pro 状态

IDA Pro 8.3 仍在分析50MB Go二进制（耗时较长）。Capstone反汇编已完整覆盖所有目标函数，结果可信度高（基于指令级分析 + RIP相对寻址解析 + 字符串引用解析）。

## 7. 交叉引用

- [Ghidra分析总览](./Ghidra分析总览.md)
- [关键地址与常量](./关键地址与常量.md)
- [decryptAccessPoint分析](../04_加密方案逆向/decryptAccessPoint分析.md)
