# PayloadSecret 调用链分析

> 文档日期: 2026-09-16
> 状态: ✅ 完成
> 数据来源: payload_secret_summary.md, payload_secret_decompiled.txt (447KB)

---

## 1. 核心结论

**payloadSecret 是服务器端提供的共享密钥**，通过 API 配置响应（X25519-HKDF-SHA256-AES-256-GCM 加密）传递给客户端。

- 不是从 X25519 派生
- 不是从 tunnel_uuid 派生
- 不是从用户密码派生
- 不是从另一个API端点获取
- **就是服务器返回的 "replace-with-a-random-shared-secret" 字符串本身，直接传给SHA256**

## 2. PayloadSecret 方法反编译

### (*Websocket).PayloadSecret @ 0x140349220

```go
// 源码: transport/argo/dialer.go:707
func (*Websocket) PayloadSecret() string {
    if self.config != nil {
        return self.config.PayloadSecret  // 直接返回Config字段
    }
    return ""
}
```

### (*RouteRacer).PayloadSecret @ 0x140365ee0

```go
// 源码: transport/argo/route_racer.go:1342
func (*RouteRacer) PayloadSecret() string {
    if self != nil && self.base != nil {
        return self.base.PayloadSecret  // 直接返回Config字段
    }
    return ""
}
```

**结论**: 两个方法都只是简单地返回 `Config.PayloadSecret` 字段，没有任何计算或派生。

## 3. 完整调用链

### 第1步: API配置请求 (fetchConfigs @ 0x14052ccc0)

源码: windows/ui/user_api.go:390

1. 检查 session 中是否有 NodeConfigHash 和 NodeConfigPayload
2. 如果有缓存，添加 config_hash 查询参数
3. 调用 doJSONWithConfigProtectionContext 发送加密请求

### 第2步: 配置保护上下文 (doJSONWithConfigProtectionContext @ 0x1405322e0)

源码: windows/ui/user_api.go:931

1. 构建 API URL
2. JSON序列化请求体，设置 Content-Type
3. 设置 Authorization header
4. **配置保护**: 调用 NewConfigResponseRequestKey() 生成 X25519 密钥对
5. 将编码后的公钥放入 X-Cftun-Config-Key HTTP header
6. 发送 HTTP 请求
7. 读取响应体
8. **调用 DecryptResponse 解密响应**
9. JSON反序列化解密后的数据

### 第3步: X25519密钥对生成 (NewConfigResponseRequestKey @ 0x1404eaa40)

源码: controlplane/config_response_crypto.go:46

```go
func NewConfigResponseRequestKey() *ConfigResponseRequestKey {
    privateKey := x25519.GenerateKey()
    publicKey := privateKey.PublicKey()
    encodedPublicKey := base64url.Encode(publicKey)
    return &ConfigResponseRequestKey{
        privateKey: privateKey,
        encodedPublicKey: encodedPublicKey,
    }
}
```

### 第4步: 配置响应解密 (DecryptResponse @ 0x1404eaec0)

源码: controlplane/config_response_crypto.go:89

1. JSON解析外层信封 {version, algorithm, serverPublicKey, salt, nonce, ciphertext}
2. 检查 version==1 && algorithm=="X25519-HKDF-SHA256-AES-256-GCM"
3. Base64URL解码各字段
4. ECDH共享密钥: X25519(clientPrivateKey, serverPublicKey)
5. HKDF派生: HKDF-SHA256(sharedSecret, salt, "cftun-config-response-v1", 32)
6. AES-256-GCM解密 (AAD = "cftun-config-response-v1")

### 第5步: 配置解析 (configsFromPayload @ 0x14052d2a0)

源码: windows/ui/user_api.go:441

1. 从解密后的JSON中提取配置列表
2. 对每个节点调用 anyMap.toRemoteConfig
3. JSON字段映射:
   - "payload_secret" → remoteConfig.PayloadSecret
   - "access_point" → remoteConfig.AccessPoint
   - "tunnel_uuid" → remoteConfig.TunnelUuid
   - "virtual_ip" → remoteConfig.VirtualIP
   - "exit_server_ip" → remoteConfig.ExitServerIP

### 第6步: 配置保存与隧道启动

1. saveRemoteLocalTunnelConfig (0x140526fa0) - 保存配置到本地
2. IPCClientNewTunnel (0x14046fb20) - 通过IPC (gob编码) 发送 conf.Config 到隧道进程
3. 隧道进程接收 Config (包含 PayloadSecret 字段)
4. NewWebsocket(config) 或 NewRouteRacer(config) 创建传输层

### 第7步: Config.Prepare() - 使用payloadSecret解密接入点

源码: transport/argo/dialer.go:405, 地址: 0x140347920

```go
func (c *Config) Prepare() error {
    // 解密接入点地址池
    result := decodeAccessPointAddrPool(
        c.AccessPoint,
        c.PayloadSecret,  // <-- payloadSecret在这里使用
    )
    c.CdnIP = result.cdnIP
    c.poolMode = result.mode
    c.prepared = true
    return nil
}
```

### 第8步: decryptAccessPoint - 实际解密

源码: transport/argo/txt_cipher.go:39, 地址: 0x140365f60

1. key = SHA256(payloadSecret)
2. AES-256-GCM(key)
3. AAD = "cftun-txt"
4. AEAD.Open(ciphertext, nonce, aad)
5. decodeTXTBinaryPayload(plaintext)

## 4. 调用链图

```
API 服务器
  │
  ▼ (HTTP响应, X25519-HKDF-SHA256-AES-256-GCM加密)
doJSONWithConfigProtectionContext (0x1405322e0)
  │
  ├── NewConfigResponseRequestKey (0x1404eaa40)     ← 生成X25519密钥对
  ├── HTTP请求 (X-Cftun-Config-Key header)          ← 发送客户端公钥
  └── DecryptResponse (0x1404eaec0)                 ← 解密配置响应
       │
       ├── ECDH(clientPrivateKey, serverPublicKey)  ← X25519共享密钥
       ├── HKDF-SHA256(sharedSecret, salt, info)    ← 派生AES密钥
       └── AES-256-GCM.Decrypt(key, nonce, aad)     ← 解密配置JSON
            │
            ▼ (解密后JSON, 含payload_secret字段)
configsFromPayload (0x14052d2a0)
  │
  └── anyMap.toRemoteConfig (0x1405359a0)
       │
       └── payload_secret → remoteConfig.PayloadSecret
           access_point   → remoteConfig.AccessPoint
            │
            ▼
IPCClientNewTunnel (0x14046fb20)  ← gob编码发送到隧道进程
  │
  ▼
NewWebsocket(config) / NewRouteRacer(config)
  │
  └── Config.Prepare() (0x140347920)
       │
       └── decodeAccessPointAddrPool (0x140347ec0)
            │
            └── decryptAccessPoint (0x140365f60)
                 │
                 ├── key = SHA256(payloadSecret)
                 ├── AES-256-GCM(key)
                 ├── AAD = "cftun-txt"
                 └── AEAD.Open(ciphertext, nonce, aad)
                      │
                      └── decodeTXTBinaryPayload (plaintext)
                           │
                           ▼
                      CdnIP + 地址池模式
```

## 5. 关键问题解答

| 问题 | 回答 |
|------|------|
| PayloadSecret方法返回什么？ | Config.PayloadSecret字段，不是计算值 |
| payloadSecret在哪里赋值？ | NewWebsocket(config)时从Config参数赋值 |
| 从API配置响应的payload_secret字段来的？ | **是** |
| 从X25519共享密钥派生？ | **不是**，X25519仅用于解密配置响应信封 |
| 从tunnel_uuid或密码派生？ | **不是**，服务器生成的独立密钥 |
| 从另一个API端点获取？ | **不是**，就在配置响应中 |

## 6. 反编译文件

| 文件 | 大小 | 说明 |
|------|------|------|
| payload_secret_decompiled.txt | 447KB | PayloadSecret相关函数完整反编译 |
| payload_secret_summary.md | - | PayloadSecret来源链分析摘要 |

## 7. 交叉引用

- [两层加密完整方案](../04_加密方案逆向/两层加密完整方案.md)
- [decryptAccessPoint分析](../04_加密方案逆向/decryptAccessPoint分析.md)
- [函数地址与模块](../03_Go二进制分析/函数地址与模块.md)
- [关键地址与常量](./关键地址与常量.md)
