# Ghidra 分析总览

> 文档日期: 2026-09-16
> 状态: ✅ 完成
> 数据来源: decompiled_functions.txt, ghidra_decompile_summary.md

---

## 1. Ghidra 项目信息

| 属性 | 值 |
|------|-----|
| Ghidra版本 | 12.1.3 PUBLIC |
| 分析模式 | Headless |
| 项目路径 | C:\ghidra_work\proj\xtun_proj |
| 目标二进制 | xtun-windows.exe |
| 二进制大小 | 50MB (Go PE64) |
| Go版本 | 1.25.0 |
| 模块 | github.com/fmnx/cftun |

## 2. 分析配置

| 配置 | 值 |
|------|-----|
| 反编译器 | Ghidra Decompiler (C伪代码) |
| 分析脚本 | DecompileFunctionsJava.java |
| PayloadSecret脚本 | DecompilePayloadSecret.java |
| 输出文件 | decompiled_functions.txt |
| 输出大小 | 561KB, 7431行 |

## 3. 反编译的函数列表

| # | 函数 | 地址 | 源码 | 大小 |
|---|------|------|------|------|
| 1 | decryptAccessPoint | 0x140365f60 | txt_cipher.go:39 | 1039B |
| 2 | DecryptResponse | 0x1404eaec0 | config_response_crypto.go:89 | 1843B |
| 3 | decodeTXTBinaryPayload | 0x140366380 | txt_cipher.go:78 | 1081B |
| 4 | decodeAccessPointAddrPool | 0x140347ec0 | dialer.go:474 | 208B |
| 5 | authenticatedAccessPointPayload | 0x1401bf9a0 | access_point_identity.go:46 | 710B |
| 6 | decodeConfigResponsePublicKey | 0x1404eac40 | config_response_crypto.go:69 | 628B |
| 7 | decodeRawBase64URL | 0x1404eb600 | config_response_crypto.go:151 | 522B |
| 8 | splitHostAndPath | 0x140349260 | dialer.go:720 | 211B |
| 9 | parseAccessPointAddrPoolMode | 0x140347fa0 | dialer.go:491 | 371B |
| 10 | runtime.stringtoslicebyte | 0x14005ac80 | string.go:218 | 191B |
| 11 | crypto/cipher.NewGCM | 0x14016de80 | gcm.go:30 | 137B |

## 4. 关键发现

### 4.1 两个独立加密方案

Ghidra反编译确认了两个完全独立的加密方案：

**Scheme A: Access Point TXT解密 (传输层)**
```
key = SHA256(accessPoint_string)
aead = AES-256-GCM(key)
nonce = decoded[:12]
ciphertext = decoded[12:]
AAD = "cftun-txt"
plaintext = aead.Open(nonce, ciphertext, AAD)
→ decodeTXTBinaryPayload(plaintext) → "host1:port1,host2:port2;RR"
```

**Scheme B: Config Response解密 (控制面)**
```
sharedSecret = X25519(clientPrivateKey, serverPublicKey)
key = HKDF-SHA256(sharedSecret, salt=32bytes, info="cftun-config-response-v1", len=32)
aead = AES-256-GCM(key)
AAD = "cftun-config-response-v1"
plaintext = aead.Open(nonce=12bytes, ciphertext, AAD)
→ JSON config response
```

### 4.2 AAD值硬编码

AAD值在代码中逐字节构造，不是字符串常量：

| AAD | Hex | 构造方式 |
|-----|-----|----------|
| cftun-txt | 63 66 74 75 6e 2d 74 78 74 | movabs + mov byte |
| cftun-config-response-v1 | 63 66 74 75 6e 2d 63 6f 6e 66 69 67 2d 72 65 73 70 6f 6e 73 65 2d 76 31 | 逐字节构造 |

### 4.3 密钥派生确认

- **配置响应**: X25519 ECDH + HKDF-SHA256
- **Access Point**: 仅SHA256(payloadSecret)，无额外KDF

## 5. cftun相关字符串

从5863个Go字符串中提取的cftun相关字符串：

```
\.pipecftun_status_
cftun-runtime-update-v1
cftun websocket v3 open key
cftun websocket v3 client to server key
__cftun_runtime_update_capability__
https://github.com/fmnx/cftun
https://cftun.com/
WSS  edge.jp.cftun.example
WS  edge.sg.cftun.example
WSS  edge.us.cftun.example
```

## 6. 反编译脚本

| 脚本 | 说明 |
|------|------|
| ghidra_scripts/DecompileFunctionsJava.java | 主反编译脚本，反编译所有关键函数 |
| ghidra_scripts/DecompilePayloadSecret.java | PayloadSecret相关函数反编译 |

## 7. 交叉引用

- [IDA分析总览](./IDA分析总览.md)
- [关键地址与常量](./关键地址与常量.md)
- [PayloadSecret调用链](./PayloadSecret调用链.md)
- [decryptAccessPoint分析](../04_加密方案逆向/decryptAccessPoint分析.md)
