# decodeTXTBinaryPayload 格式解析

> 文档日期: 2026-09-16
> 状态: ✅ 完成
> 数据来源: ghidra_decompile_summary.md, ida_decompile_summary.md

---

## 1. 函数基本信息

| 属性 | 值 |
|------|-----|
| 函数名 | decodeTXTBinaryPayload |
| VA地址 | 0x140366380 |
| 源码位置 | transport/argo/txt_cipher.go:78 |
| 函数大小 | 1081字节 |
| 签名 | func decodeTXTBinaryPayload(data []byte) (string, error) |

## 2. 二进制格式

```
┌─────────────────────────────────────────────┐
│ byte 0: mode flags                          │
│   bits 0-1: mode                             │
│     0 = plain (无后缀)                       │
│     1 = Round Robin (追加 ";RR")            │
│     2 = Random (追加 ";RD")                 │
│     3 = error (无效)                         │
│   bits 2-7: 必须为0                          │
├─────────────────────────────────────────────┤
│ byte 1..N: uvarint entryCount               │
│   (Go标准uvarint编码, 最大0x10000)           │
├─────────────────────────────────────────────┤
│ entry[0]:                                    │
│   1 byte type tag (0x22='"' 或 0x23='#')    │
│   4 bytes IPv4地址 (大端序)                   │
│   2 bytes terminator (0x00 0x50)             │
├─────────────────────────────────────────────┤
│ entry[1]: ...                                │
│ ...                                          │
│ entry[entryCount-1]: ...                     │
└─────────────────────────────────────────────┘
```

## 3. mode字节

| mode值 | 含义 | 输出后缀 |
|--------|------|----------|
| 0 | plain (普通) | 无 |
| 1 | RR (Round Robin) | ;RR |
| 2 | RD (Random) | ;RD |
| 3 | error | 返回错误 |

mode提取: `byte & 0x03`，高位 `byte & 0xFC` 必须为0。

## 4. entry结构

每个entry结构：

| 偏移 | 长度 | 内容 | 说明 |
|------|------|------|------|
| 0 | 1字节 | type tag | 0x22 ('"') 或 0x23 ('#') |
| 1 | 4字节 | IPv4地址 | 大端序 (如 0x186ca2c6 = 24.108.162.198) |
| 5 | 2字节 | terminator | 0x00 0x50 (固定) |

总长度: 7字节/entry

## 5. IP提取方式

从4字节IPv4地址提取IP：

```python
def extract_ip(data, offset):
    # 4字节大端序IPv4
    ip = f"{data[offset]}.{data[offset+1]}.{data[offset+2]}.{data[offset+3]}"
    return ip

# 示例: hex 18 6c a2 c6 → 24.108.162.198
```

## 6. 解析示例

### Node 1 (东京·节点1) 明文

```
plaintext hex: 000423186ca2c600502317a29f2600502317a29f2c00502317ac40340050

解析:
  byte 0: 0x00 → mode=0 (plain)
  uvarint: 0x04 → entryCount=4
  
  entry[0]: type=0x23, ip=18.6c.a2.c6=24.108.162.198, term=00.50
  entry[1]: type=0x23, ip=17.a2.9f.26=23.162.159.38,  term=00.50
  entry[2]: type=0x23, ip=17.a2.9f.2c=23.162.159.44,  term=00.50
  entry[3]: type=0x23, ip=17.ac.40.34=23.172.64.52,   term=00.50

结果: "24.108.162.198:80,23.162.159.38:80,23.162.159.44:80,23.172.64.52:80"
```

### Node 6 (香港·节点1) 明文

```
plaintext hex: 0014220894fee000502208a36b740050...

解析:
  byte 0: 0x00 → mode=0 (plain)
  uvarint: 0x14 → entryCount=20
  
  entry[0]: type=0x22, ip=08.94.fe.e0=8.148.254.224, term=00.50
  entry[1]: type=0x22, ip=08.a3.6b.74=8.163.107.116, term=00.50
  ... (共20个entry)

结果: "8.148.254.224:80,8.163.107.116:80,..." (20个IP)
```

## 7. 端口说明

所有节点的端口固定为 **80** (从节点配置的 port 字段获取，不在二进制payload中编码)。

## 8. type tag含义

| tag | Hex | ASCII | 说明 |
|-----|-----|-------|------|
| 0x22 | 0x22 | '"' | WebSocket entry |
| 0x23 | 0x23 | '#' | 标准entry |

两种tag在解密结果中处理方式相同，都提取4字节IPv4。

## 9. 解析代码

```python
def decode_txt_binary_payload(data: bytes) -> str:
    """解析decodeTXTBinaryPayload格式的二进制数据"""
    if len(data) < 1:
        return ""
    
    # mode
    mode = data[0] & 0x03
    if mode == 3:
        raise ValueError("invalid mode")
    if data[0] & 0xFC != 0:
        raise ValueError("invalid mode flags")
    
    # uvarint entryCount
    offset = 1
    entry_count, offset = decode_uvarint(data, offset)
    
    # 解析entries
    ips = []
    for i in range(entry_count):
        if offset + 7 > len(data):
            break
        type_tag = data[offset]
        ip = f"{data[offset+1]}.{data[offset+2]}.{data[offset+3]}.{data[offset+4]}"
        # terminator = data[offset+5:offset+7]  # 0x00 0x50
        ips.append(f"{ip}:80")
        offset += 7
    
    result = ",".join(ips)
    if mode == 1:
        result += ";RR"
    elif mode == 2:
        result += ";RD"
    
    return result

def decode_uvarint(data: bytes, offset: int) -> tuple:
    """Go标准uvarint解码"""
    result = 0
    shift = 0
    while offset < len(data):
        b = data[offset]
        result |= (b & 0x7F) << shift
        offset += 1
        if b & 0x80 == 0:
            break
        shift += 7
    return result, offset
```

## 10. 交叉引用

- [decryptAccessPoint分析](./decryptAccessPoint分析.md)
- [两层加密完整方案](./两层加密完整方案.md)
- [节点解密流程](../07_节点解密/节点解密流程.md)
