# decryptAccessPoint 函数分析

> 文档日期: 2026-09-16
> 状态: ✅ 完成
> 数据来源: ghidra_decompile_summary.md, ida_decompile_summary.md, decompiled_functions.txt

---

## 1. 函数基本信息

| 属性 | 值 |
|------|-----|
| 函数名 | decryptAccessPoint |
| VA地址 | 0x140365f60 |
| 源码位置 | transport/argo/txt_cipher.go:39 |
| 函数大小 | 1039字节 |
| 签名 | func decryptAccessPoint(accessPoint string, payloadSecret string) (string, error) |
| Go全名 | github.com/fmnx/cftun/backend/transport/argo.decryptAccessPoint |

## 2. 执行流程

```
输入: accessPoint (string), payloadSecret (string)
  │
  ├── 1. TrimSpace(accessPoint)
  ├── 2. TrimSpace(payloadSecret)
  ├── 3. 如果任一为空 → 返回error
  │
  ├── 4. decoded = base64.URLEncoding.DecodeString(payloadSecret)
  ├── 5. 验证 payloadSecret == base64url(decoded)  // 往返检查
  │
  ├── 6. key = sha256.Sum256([]byte(accessPoint))  // 32字节AES-256密钥
  ├── 7. block = aes.NewCipher(key)
  ├── 8. aead = cipher.NewGCM(block)  // nonce=12, tag=16
  │
  ├── 9. nonceSize = aead.NonceSize()  // 12
  ├── 10. overhead = aead.Overhead()   // 16
  ├── 11. 如果 len(decoded) < nonceSize + overhead → error
  │
  ├── 12. nonce = decoded[:nonceSize]       // 前12字节
  ├── 13. ciphertext = decoded[nonceSize:]  // 剩余字节
  ├── 14. AAD = []byte("cftun-txt")         // 9字节
  │
  ├── 15. plaintext = aead.Open(nil, nonce, ciphertext, AAD)
  ├── 16. result = decodeTXTBinaryPayload(plaintext)
  │
  └── 返回 result
```

## 3. 密钥派生 (SHA256)

```
key = SHA256(payloadSecret.encode())

payloadSecret = "replace-with-a-random-shared-secret"
key = SHA256(b"replace-with-a-random-shared-secret")
   = 5399557b5b0b3e1c7704b27082a2d746d615e1f4c70718e8976e3868e0a82f52
```

**注意**: 密钥派生仅使用SHA256，无HKDF/PBKDF2/Argon2/scrypt等额外KDF。密钥材料直接来自payloadSecret字符串。

## 4. AAD构造 (逐字节)

AAD值 `cftun-txt` 在代码中不是字符串常量，而是逐字节构造：

### Ghidra反编译确认

```
0x14036622c: movabs rdi, 0x78742d6e75746663  → "cftun-tx" (前8字节, 小端序)
0x140366239: mov byte ptr [rax + 8], 0x74    → 't' (第9字节)
0x14036625c: mov qword ptr [rsp + 0x20], 9   → AAD长度=9
```

### AAD字节

| 位置 | Hex | ASCII |
|------|-----|-------|
| 0 | 0x63 | c |
| 1 | 0x66 | f |
| 2 | 0x74 | t |
| 3 | 0x75 | u |
| 4 | 0x6e | n |
| 5 | 0x2d | - |
| 6 | 0x74 | t |
| 7 | 0x78 | x |
| 8 | 0x74 | t |

## 5. GCM参数

| 参数 | 值 | 说明 |
|------|-----|------|
| 算法 | AES-256-GCM | 标准GCM |
| 密钥长度 | 32字节 (256位) | AES-256 |
| Nonce长度 | 12字节 | 标准GCM nonce |
| Tag长度 | 16字节 | 标准GCM tag |
| AAD | "cftun-txt" (9字节) | 硬编码 |
| 布局 | nonce(12) + ciphertext + tag(16) | Go标准GCM格式 |

## 6. GCM创建过程 (从Capstone反汇编)

```
1. 准备32字节AES密钥 (sub_5ac80 @ 0x14005ac80)
   - 清零32字节缓冲区 (xmm15 zero fill)
   - 复制密钥材料到缓冲区 (memmove)

2. 创建AES-256密码 (0x14016fae0)
   - AES密钥扩展 (0x14055fdc0, 0x14055fec0)
   - 块加密设置 (0x140560180, edi=0x20=32)

3. 创建GCM模式 (0x14016f840)
   - 验证密钥长度: 16/24/32字节
   - GCM上下文初始化 (0x14056be20)

4. 创建GCM (cipher.NewGCM @ 0x14016de80)
   - nonce_size=12, tag_size=16
   - 标准GCM参数

5. 设置AAD = "cftun-txt" (硬编码9字节)

6. GCM.Open() 解密 (0x14036628b, call rdx)
   - AES-256-GCM解密，使用AAD

7. decodeTXTBinaryPayload (0x140366380) 解析解密数据
```

## 7. 反编译代码片段 (Ghidra C伪代码)

```c
// 简化伪代码
string decryptAccessPoint(string accessPoint, string payloadSecret) {
    accessPoint = strings.TrimSpace(accessPoint);
    payloadSecret = strings.TrimSpace(payloadSecret);
    if (accessPoint == "" || payloadSecret == "") return error;

    // Base64URL解码
    decoded = base64.URLEncoding.DecodeString(payloadSecret);

    // 密钥 = SHA256(accessPoint)
    key = sha256.Sum256([]byte(accessPoint));  // 32 bytes

    // AES-256-GCM
    block = aes.NewCipher(key);
    aead = cipher.NewGCM(block);

    // 提取nonce和ciphertext
    nonce = decoded[:aead.NonceSize()];        // 12 bytes
    ciphertext = decoded[aead.NonceSize():];   // remaining

    // AAD = "cftun-txt" (逐字节构造)
    aad = []byte{0x63, 0x66, 0x74, 0x75, 0x6e, 0x2d, 0x74, 0x78, 0x74};

    // 解密
    plaintext = aead.Open(nil, nonce, ciphertext, aad);

    // 解码TXT二进制负载
    result = decodeTXTBinaryPayload(plaintext);
    return result;
}
```

## 8. 交叉引用

- [两层加密完整方案](./两层加密完整方案.md)
- [decodeTXTBinaryPayload格式](./decodeTXTBinaryPayload格式.md)
- [Ghidra分析总览](../05_静态分析/Ghidra分析总览.md)
- [IDA分析总览](../05_静态分析/IDA分析总览.md)
