# xTun 完整逆向分析报告

> 文档日期: 2026-09-16
> 状态: ✅ 完成
> 项目路径: E:\逆向\XTun

---

## 1. 执行摘要

xTun (com.xtun, v1.0.9) 是一个基于 Flutter + Go 架构的 VPN 应用，使用自研 "cftun WebSocket v3" 协议。本次逆向分析完整破解了其两层加密方案，成功提取全部19个节点的173个endpoint IP，并生成了代理配置模板。

### 核心成果

| 成果 | 状态 |
|------|------|
| 两层加密方案完全逆向 | ✅ |
| 19个节点全部解密 | ✅ |
| 173个endpoint IP提取 | ✅ |
| 5个服务器集群映射 | ✅ |
| 代理配置模板生成 | ✅ |

## 2. 应用信息

| 属性 | 值 |
|------|-----|
| 应用名称 | xTun |
| 包名 | com.xtun |
| 版本 | 1.0.9 |
| 架构 | Flutter (UI) + Go (核心) |
| Go模块 | github.com/fmnx/cftun/backend@v0.0.0 |
| Go版本 | 1.25.0 |
| 二进制 | xtun-windows.exe (PE64, 50MB) |
| 协议 | cftun WebSocket v3 (自研) |
| API | api.xtun.link |

## 3. 加密方案总结

### 3.1 两层加密架构

| 层级 | 算法 | 密钥来源 | AAD | 用途 |
|------|------|----------|-----|------|
| 第一层 | X25519-HKDF-SHA256-AES-256-GCM | ECDH + HKDF | cftun-config-response-v1 (24B) | API配置响应传输 |
| 第二层 | AES-256-GCM | SHA256(payloadSecret) | cftun-txt (9B) | access_point解密 |

### 3.2 第一层: 配置响应传输加密

```
1. 客户端生成X25519密钥对 → 公钥放入 X-Cftun-Config-Key header
2. 服务器返回 {version, algorithm, server_public_key, salt, nonce, ciphertext}
3. shared = X25519(client_priv, server_pub)
4. aesKey = HKDF-SHA256(shared, salt, "cftun-config-response-v1", 32)
5. plaintext = AES-256-GCM(aesKey, nonce, ciphertext, AAD="cftun-config-response-v1")
```

### 3.3 第二层: access_point解密

```
1. raw = base64url_decode(access_point)
2. nonce = raw[:12], ct_with_tag = raw[12:]
3. key = SHA256("replace-with-a-random-shared-secret")
   = 5399557b5b0b3e1c7704b27082a2d746d615e1f4c70718e8976e3868e0a82f52
4. plaintext = AES-256-GCM(key, nonce, ct_with_tag, AAD="cftun-txt")
5. result = decodeTXTBinaryPayload(plaintext) → "IP:port,IP:port;RR"
```

### 3.4 payloadSecret来源

payloadSecret = "replace-with-a-random-shared-secret"

- 来自API配置响应解密后的JSON字段 `config.payload_secret`
- 不是从X25519、tunnel_uuid或用户密码派生
- 服务器生成的独立密钥（当前为占位符值）
- 直接传给SHA256生成AES密钥

## 4. API端点总结

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| /v1/auth/login | POST | Origin | 登录获取JWT |
| /v1/public/node/list | GET | JWT + Origin + X-Cftun-Config-Key | 节点列表 (加密响应) |
| /v1/public/node/catalog.dat | GET | JWT + Origin | 节点目录 |
| /v1/public/user/info | GET | JWT + Origin | 用户信息 |
| /v1/common/site/config | GET | 公开 | 站点配置 |

## 5. 节点信息总结

### 5.1 统计

| 指标 | 值 |
|------|-----|
| 总节点数 | 19 |
| 国家/地区 | 12 |
| 服务器集群 | 5 |
| 总endpoint IP | 173 |
| 传输方式 | websocket (12), implicit_websocket (7) |
| 端口 | 80 (全部) |
| TLS | 否 (全部) |

### 5.2 服务器集群

| 集群 | 关联节点 | IP数量 | 位置 |
|------|---------|--------|------|
| 东京集群 | 1, 10, 18 | 4 | JP, US |
| 新加坡集群 | 4, 19, 20, 21, 22 | 4 | SG, ID, IN |
| 法兰克福集群 | 5, 13, 14, 15, 16 | 4 | DE, US, GB, CA |
| 香港集群 | 2, 6, 23, 24, 25 | 20 | CN, TH, VN |
| 首尔集群 | 26 | 21 | KR |

### 5.3 协议参数

| 参数 | 值 |
|------|-----|
| 传输层 | WebSocket (ws://) |
| TLS | 否 |
| 端口 | 80 |
| 子协议 | cftun websocket v3 |
| 密钥交换 | X25519 |
| 数据加密 | ChaCha20-Poly1305 |
| Host头 | as6185.net 或 tanfasy.com |
| WebSocket路径 | / |

## 6. 关键函数地址

| 函数 | 地址 | 源码 |
|------|------|------|
| decryptAccessPoint | 0x140365f60 | txt_cipher.go:39 |
| DecryptResponse | 0x1404eaec0 | config_response_crypto.go:89 |
| decodeTXTBinaryPayload | 0x140366380 | txt_cipher.go:78 |
| decodeAccessPointAddrPool | 0x140347ec0 | dialer.go:474 |
| Config.Prepare | 0x140347920 | dialer.go:405 |

## 7. 使用说明

### 7.1 ⚠️ 协议限制

**cftun WebSocket v3 是自研协议，标准 v2ray/xray/Clash 客户端无法直接连接。**

生成的 v2ray 和 Clash 配置仅为结构化模板。

### 7.2 使用xTun官方客户端 (推荐)

客户端配置: `C:\Users\Administrator\AppData\Local\xTun\user.json`

### 7.3 连接测试

```bash
python test_connection.py
```

### 7.4 API重新获取节点

使用 [API请求模板代码](../02_API逆向/API端点与认证.md#5-api-请求模板代码) 重新登录并解密获取最新节点。

## 8. 局限性说明

| 局限 | 说明 |
|------|------|
| 自研协议 | cftun WebSocket v3 无法被标准客户端直连 |
| Token过期 | 账号UserId=9的token有时过期，需重新登录 |
| Access Point轮换 | 每次API请求access_point会变，但endpoint IP不变 |
| Frida动态验证 | 账号token过期，未捕获到运行时解密数据 (静态分析已完全确认) |
| payloadSecret占位符 | "replace-with-a-random-shared-secret" 可能是服务器未生成真实密钥的占位符 |
| IDA分析 | 50MB Go二进制，IDA Pro分析耗时较长，主要依赖Capstone |

## 9. 分析工具

| 工具 | 版本 | 用途 |
|------|------|------|
| Ghidra | 12.1.3 | 反编译 (C伪代码) |
| IDA Pro | 8.3 | 反编译 (辅助) |
| Capstone | 5.0.7 | 反汇编 |
| Frida | - | 动态hook |
| Python | 3.12 | 脚本 |
| PyCryptodome | - | AES-256-GCM |
| cryptography | - | X25519, HKDF |

## 10. 子代理任务汇总

| # | 任务 | 状态 | 关键产出 |
|---|------|------|----------|
| 1 | Ghidra Java反编译 | ✅ | decompiled_functions.txt (561KB) |
| 2 | IDA/Capstone反编译 | ✅ | ida_decompiled.json, 交叉验证 |
| 3 | Frida动态Hook | 🔄 | 验证性质 (静态分析已确认) |
| 4 | API+access_point解密 | ✅ | 19节点IP全部提取 |
| 5 | PayloadSecret溯源 | ✅ | payload_secret_decompiled.txt (447KB) |
| 6 | 代理配置生成 | ✅ | v2ray/clash/cftun配置文件 |

## 11. 文件索引

### 逆向分析
- [项目概述](../00_项目概述/项目概述.md)
- [APK结构分析](../01_APK分析/APK结构分析.md)
- [API端点与认证](../02_API逆向/API端点与认证.md)
- [配置响应解密](../02_API逆向/配置响应解密.md)
- [函数地址与模块](../03_Go二进制分析/函数地址与模块.md)
- [Go二进制信息](../03_Go二进制分析/Go二进制信息.md)
- [两层加密完整方案](../04_加密方案逆向/两层加密完整方案.md)
- [decryptAccessPoint分析](../04_加密方案逆向/decryptAccessPoint分析.md)
- [decodeTXTBinaryPayload格式](../04_加密方案逆向/decodeTXTBinaryPayload格式.md)
- [Ghidra分析总览](../05_静态分析/Ghidra分析总览.md)
- [IDA分析总览](../05_静态分析/IDA分析总览.md)
- [关键地址与常量](../05_静态分析/关键地址与常量.md)
- [PayloadSecret调用链](../05_静态分析/PayloadSecret调用链.md)
- [FridaHook分析](../06_动态分析/FridaHook分析.md)
- [节点解密流程](../07_节点解密/节点解密流程.md)
- [19个节点完整列表](../07_节点解密/19个节点完整列表.md)
- [代理配置生成](../07_节点解密/代理配置生成.md)
- [脚本清单](../08_分析脚本/脚本清单.md)
- [原始文件索引](../09_原始数据/原始文件索引.md)
- [逆向分析总结](./逆向分析总结.md)

### 原始数据
- [原始文件索引](../09_原始数据/原始文件索引.md)
