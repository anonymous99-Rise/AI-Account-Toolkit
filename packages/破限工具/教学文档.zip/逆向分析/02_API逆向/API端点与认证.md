# xTun API 端点与认证方式

> 文档日期: 2026-09-16
> 状态: ✅ 完成

---

## 1. API 基础信息

| 属性 | 值 |
|------|-----|
| API域名 | api.xtun.link |
| 协议 | HTTPS (TLS) |
| CDN | Cloudflare |
| 客户端域名 | xtun.link |

## 2. 认证方式

### 2.1 裸 JWT + Origin 头

所有认证请求需要两个头：

| 头 | 值 | 说明 |
|----|-----|------|
| Authorization | <JWT token> | 裸JWT，无"Bearer "前缀 |
| Origin | https://xtun.link | 必须设置，服务器验证 |

### 2.2 X-Cftun-Config-Key 头

配置请求需要额外的加密头：

| 头 | 值 | 说明 |
|----|-----|------|
| X-Cftun-Config-Key | base64url(X25519_public_key) | 客户端X25519公钥，用于配置响应加密 |

**机制说明**: 客户端每次请求配置时生成临时X25519密钥对，将公钥通过此头发送给服务器。服务器使用自己的私钥和客户端公钥进行ECDH协商，派生AES密钥加密响应。这是前向保密设计。

## 3. API 端点列表

### 3.1 登录

```
POST /v1/auth/login
Content-Type: application/json
Origin: https://xtun.link

请求体:
{
  "email": "anchastonmicarp1997@outlook.com",
  "password": "Sagamoto%3844"
}

响应:
{
  "code": 200,
  "data": {
    "token": "<JWT>",
    "tunnel_uuid": "01a093f1-0028-7ad6-98d2-54c12183dc79"
  }
}
```

### 3.2 节点列表 (配置响应)

```
GET /v1/public/node/list
Authorization: <JWT>
Origin: https://xtun.link
X-Cftun-Config-Key: <base64url(X25519_pubkey)>

响应: 加密的配置信封 (见 配置响应解密.md)
```

### 3.3 节点目录

```
GET /v1/public/node/catalog.dat
Authorization: <JWT>
Origin: https://xtun.link

响应: 加密的节点目录数据
```

### 3.4 用户信息

```
GET /v1/public/user/info
Authorization: <JWT>
Origin: https://xtun.link
```

### 3.5 站点配置 (公开)

```
GET /v1/common/site/config
```

## 4. 请求/响应格式

### 4.1 标准响应结构

```json
{
  "code": 200,
  "msg": "success",
  "data": { ... }
}
```

### 4.2 错误响应

| code | msg | 说明 |
|------|-----|------|
| 40004 | User token is expired | Token过期/账号被封 |
| 200 | success | 成功 |

## 5. API 请求模板代码

```python
import socket, ssl, json, base64, hashlib
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from Crypto.Cipher import AES

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def b64url_decode(s):
    if isinstance(s, str): s = s.encode()
    pad = (4 - len(s) % 4) % 4
    return base64.urlsafe_b64decode(s + b'=' * pad)

def raw_https(method, path, extra_headers=None, json_body=None):
    s = socket.create_connection(('api.xtun.link', 443), timeout=20)
    ss = ctx.wrap_socket(s, server_hostname='api.xtun.link')
    parts = [f'{method} {path} HTTP/1.1', 'Host: api.xtun.link']
    if extra_headers:
        for k, v in extra_headers.items():
            parts.append(f'{k}: {v}')
    parts.append('User-Agent: Mozilla/5.0')
    parts.append('Connection: close')
    payload = b''
    if json_body is not None:
        payload = json.dumps(json_body).encode()
        parts.append(f'Content-Length: {len(payload)}')
        parts.append('Content-Type: application/json')
    parts.extend(['', ''])
    req = '\r\n'.join(parts).encode() + payload
    ss.send(req)
    resp = b''
    while True:
        try:
            c = ss.recv(65536)
            if not c: break
            resp += c
        except: break
    ss.close()
    idx = resp.index(b'\r\n\r\n')
    return resp[:idx].decode('utf-8','replace'), resp[idx+4:]

# 1. 登录
h, b = raw_https('POST', '/v1/auth/login',
    extra_headers={'Origin': 'https://xtun.link'},
    json_body={'email': 'anchastonmicarp1997@outlook.com', 'password': 'Sagamoto%3844'})
token = json.loads(b)['data']['token']

# 2. X25519 + 获取配置
pk = X25519PrivateKey.generate()
pub = pk.public_key().public_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PublicFormat.Raw)
pub_b64 = base64.urlsafe_b64encode(pub).rstrip(b'=').decode()

h, b = raw_https('GET', '/v1/public/node/list',
    extra_headers={'Authorization': token, 'Origin': 'https://xtun.link',
                   'X-Cftun-Config-Key': pub_b64})
cfg_resp = json.loads(b)
```

## 6. 注意事项

- API域名 `api.xtun.link` 通过 Cloudflare CDN，有时返回404需重试
- Access Point 每次API请求会轮换，但 endpoint IP 保持不变
- 账号 UserId=9 的 token 有时过期，需重新登录

## 7. 交叉引用

- [配置响应解密](./配置响应解密.md)
- [两层加密完整方案](../04_加密方案逆向/两层加密完整方案.md)
- [PayloadSecret调用链](../05_静态分析/PayloadSecret调用链.md)
