# Frida Hook 动态分析

> 文档日期: 2026-09-16
> 状态: 🔄 部分完成
> 数据来源: frida_crypto_results.json

---

## 1. Frida Hook 概述

| 属性 | 值 |
|------|-----|
| 工具 | Frida |
| 目标进程 | xtun-windows.exe /managerservice |
| 模块基址 | 0x7ff7934b0000 (ASLR, 动态) |
| Hook状态 | 安装成功 |
| 运行时数据 | 未捕获 (账号token过期，进程使用缓存配置) |

## 2. Hook 的函数

| # | 函数 | RVA | 说明 |
|---|------|-----|------|
| 1 | decryptAccessPoint | 0x365f60 | access_point解密 |
| 2 | sha256.Sum256 | 0x16fae0 | SHA256哈希 |
| 3 | aes.NewCipher | 0x16f840 | AES密码创建 |
| 4 | sub_5ac80 | 0x5ac80 | 密钥准备 |
| 5 | sub_366380 | 0x366380 | decodeTXTBinaryPayload |
| 6 | processConfigResponse | 0x4eaec0 | 配置响应处理 |
| 7 | ecdh_ECDH | 0x20f1c0 | X25519 ECDH |
| 8 | hkdfDerive | 0x427ec0 | HKDF派生 |
| 9 | cipher.NewGCM | 0x16de80 | GCM创建 |
| 10 | base64DecodeString | 0x170580 | Base64解码 |

## 3. Hook 结果

```json
{
  "status": "BLOCKED",
  "reason": "Account UserId=9 is still banned on server. All authenticated API endpoints return code 40004 'User token is expired'.",
  "frida_hooks": {
    "status": "installed_successfully",
    "result": "No crypto functions were called - process uses cached config from disk"
  }
}
```

### 结果分析

- **Hook安装**: 成功，所有10个函数的hook都已安装
- **函数调用**: 无任何加密函数被调用
- **原因**: 进程使用磁盘缓存的配置 (user.json)，未触发API请求和解密流程
- **账号状态**: UserId=9 的token过期，API返回 code=40004

## 4. 运行时验证

由于Frida未捕获到运行时数据，运行时验证依赖于静态分析的可靠性：

| 验证项 | 静态分析确认 | 运行时验证 |
|--------|-------------|-----------|
| AAD = "cftun-txt" | ✅ Ghidra + Capstone | ⏳ 未捕获 |
| 密钥 = SHA256(payloadSecret) | ✅ Ghidra + Capstone | ⏳ 未捕获 |
| AES-256-GCM | ✅ Ghidra + Capstone | ⏳ 未捕获 |
| Nonce = 12字节 | ✅ Ghidra + Capstone | ⏳ 未捕获 |
| Tag = 16字节 | ✅ Ghidra + Capstone | ⏳ 未捕获 |

**结论**: 静态分析已完全确认所有加密参数，实际解密成功（19节点IP全部提取）间接验证了静态分析的正确性。

## 5. 加密架构 (Frida确认)

```json
{
  "algorithm": "X25519-HKDF-SHA256-AES-256-GCM",
  "flow": [
    "1. Base64 decode server_public_key -> 32 bytes",
    "2. X25519 ECDH(client_private, server_public) -> shared_secret",
    "3. HKDF-SHA256(shared_secret, salt, 'cftun-config-response-v1') -> payloadSecret",
    "4. AES-256-GCM.Open(nonce, ciphertext, nil) -> plaintext config",
    "5. AES_key = SHA256(payloadSecret) for access_point decryption"
  ],
  "hkdf_info": "cftun-config-response-v1",
  "nonce_length": 12,
  "salt_length": 32,
  "key_length": 32
}
```

## 6. API端点 (Frida确认)

```json
{
  "base_url": "https://api.xtun.link",
  "login": "POST /v1/auth/login",
  "node_list": "GET /v1/public/node/list (with X-Cftun-Config-Key header)",
  "user_info": "GET /v1/public/user/info",
  "site_config": "GET /v1/common/site/config (public)"
}
```

## 7. 进程信息

| 进程 | 参数 | 说明 |
|------|------|------|
| 服务 | xtun-windows.exe /managerservice | session 0 |
| GUI | xtun-windows.exe /ui | console session |
| 本地API端口 | 19770 | - |

## 8. 已有数据

| 文件 | 说明 |
|------|------|
| config_response.json | 加密的配置响应 (18.9KB) |
| catalog_decrypted.json | 57个access point (41.3KB) |
| user.json | 缓存的nodeConfigPayload (19个access point) |
| key_derivation_data.json | 加密架构文档 |

## 9. Frida脚本

| 脚本 | 说明 |
|------|------|
| frida_find_func.py | 函数查找 |
| frida_scan.py | 内存扫描 |
| frida_spawn_v2.py | Spawn模式hook |
| hook_payload_secret.py | PayloadSecret hook |
| hook_service.py | 服务hook |
| hook_with_ui.py | UI hook |
| run_frida_hook.py | 主hook脚本 |
| scan_memory.py | 内存扫描 |
| service_frida_hook.py | 服务Frida hook |
| spawn_frida_hook.py | Spawn hook |
| quick_attach.py | 快速attach |

## 10. 交叉引用

- [Ghidra分析总览](../05_静态分析/Ghidra分析总览.md)
- [IDA分析总览](../05_静态分析/IDA分析总览.md)
- [两层加密完整方案](../04_加密方案逆向/两层加密完整方案.md)
- [脚本清单](../08_分析脚本/脚本清单.md)
