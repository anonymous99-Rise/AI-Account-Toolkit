# Go 二进制信息

> 文档日期: 2026-09-16
> 状态: ✅ 完成
> 数据来源: xtun-windows.exe, Ghidra 12.1.3, IDA Pro 8.3

---

## 1. 文件信息

| 属性 | 值 |
|------|-----|
| 文件名 | xtun-windows.exe |
| 完整路径 | E:\逆向\XTun\xtun-windows.exe |
| 文件大小 | 50,043,240 bytes (~47.7 MB) |
| 格式 | PE64 (Windows Portable Executable 64-bit) |
| 基地址 (ImageBase) | 0x140000000 |
| 入口点 | PE标准入口 |
| 架构 | x86-64 (AMD64) |

## 2. Go 编译信息

| 属性 | 值 |
|------|-----|
| Go版本 | 1.25.0 |
| 编译器 | Go gc compiler |
| 模块路径 | github.com/fmnx/cftun |
| 后端版本 | github.com/fmnx/cftun/backend@v0.0.0 |
| 构建模式 | exe (可执行文件) |
| CGO | 可能启用 (Flutter FFI集成) |

## 3. 依赖模块 (从字符串提取)

### 核心模块
| 模块 | 说明 |
|------|------|
| github.com/fmnx/cftun | 主项目 |
| github.com/fmnx/cftun/backend | 后端逻辑 |
| crypto/aes | AES加密 |
| crypto/cipher | GCM模式 |
| crypto/sha256 | SHA256哈希 |
| crypto/ecdh | X25519密钥交换 |
| encoding/base64 | Base64URL编码 |
| golang.org/x/crypto/hkdf | HKDF密钥派生 |

### 其他cftun相关字符串
```
\\.\pipe\cftun_status_
cftun-runtime-update-v1
cftun websocket v3 open key
cftun websocket v3 client to server key
__cftun_runtime_update_capability__
https://github.com/fmnx/cftun
https://cftun.com/
WSS  edge.jp.cftun.example
WS  edge.sg.cftun.example
WSS  edge.us.cftun.example
```

## 4. PE 信息

| 属性 | 值 |
|------|-----|
| Machine | 0x8664 (AMD64) |
| Sections | 标准PE节 (.text, .data, .rdata, etc.) |
| ASLR | 启用 (动态基址) |
| 字符串总数 | ~5863个Go字符串 |

## 5. 运行时信息

| 属性 | 值 |
|------|-----|
| Windows服务名 | CFTunManager |
| 服务参数 | /managerservice |
| GUI参数 | /ui |
| 本地API端口 | 19770 |
| IPC方式 | Named pipe (\\.\pipe\cftun_status_) |
| 客户端配置 | C:\Users\Administrator\AppData\Local\xTun\user.json |

## 6. 交叉引用

- [函数地址与模块](./函数地址与模块.md)
- [APK结构分析](../01_APK分析/APK结构分析.md)
- [Ghidra分析总览](../05_静态分析/Ghidra分析总览.md)
