# xTun 逆向工程教学

> 手把手教你从零逆向 xTun VPN，一个细节都不落。

---

## 这是什么

这是一份完整的逆向工程教学文档，教你如何：

1. 分析 xTun（Flutter + Go VPN 应用）的二进制
2. 逆向其自研 `cftun websocket v3` 协议
3. 解密节点配置，提取真实出口 IP
4. 实现纯 Python 代理，不依赖 xTun 客户端

最终产物：一个 `cftun_proxy_working.py`，对外暴露 SOCKS5 + HTTP 代理，通过 xTun 网络访问互联网。

---

## 教学目录

| 文件 | 内容 | 阶段 |
|------|------|------|
| [00-前言](00-前言-你要逆向什么.md) | xTun 是什么、为什么逆向、需要什么 | 认知 |
| [01-认识目标](01-第一步-认识目标.md) | 找到可执行文件、确认 Go 编译 | 侦察 |
| [02-准备工具](02-第二步-准备工具.md) | 安装 Ghidra/Python/依赖 | 准备 |
| [03-二进制识别](03-第三步-二进制识别.md) | PE 解析、Go 版本、节区 | 侦察 |
| [04-Ghidra导入](04-第四步-Ghidra导入分析.md) | Headless 导入、自动分析 | 静态分析 |
| [05-定位函数](05-第五步-定位关键函数.md) | 搜索字符串、找函数地址 | 静态分析 |
| [06-反编译加密](06-第六步-反编译加密函数.md) | 读伪代码、识别算法、密钥链 | 静态分析 |
| [07-逆向API](07-第七步-逆向API通信.md) | API URL、登录、认证 | 网络分析 |
| [08-解密配置](08-第八步-解密节点配置.md) | 两层 AES-GCM 解密 | 实现 |
| [09-抓包分析](09-第九步-抓包分析流量.md) | pktmon 抓包、提取 WS 帧 | 动态分析 |
| [10-测试WebSocket](10-第十步-测试WebSocket连接.md) | Host/Path/UA 组合测试 | 突破 |
| [11-协议握手](11-第十一步-实现协议握手.md) | open frame 构造与加密 | 实现 |
| [12-数据通道](12-第十二步-实现数据通道.md) | ChaCha20 双向加密通道 | 实现 |
| [13-代理功能](13-第十三步-实现代理功能.md) | SOCKS5 + HTTP 代理 | 实现 |
| [14-端到端验证](14-第十四步-端到端验证.md) | 完整测试、浏览器配置 | 验证 |
| [15-排错](15-常见问题与排错.md) | 20 个常见问题与解决 | 排错 |

---

## 快速开始

如果你只想用结果，不想走过程：

```bash
# 1. 安装依赖
pip install pycryptodome cryptography

# 2. 运行代理
python cftun_proxy_working.py

# 3. 配置浏览器
# SOCKS5: 127.0.0.1:1080
# HTTP:   127.0.0.1:8080
```

如果你想学习完整的逆向方法，从 `00-前言` 开始，一步一步走。

---

## 技术栈

| 层 | 技术 |
|----|------|
| 目标 | xTun VPN (Flutter + Go) |
| 协议 | cftun websocket v3 (自研) |
| 加密 | X25519 + HKDF-SHA256 + ChaCha20-Poly1305 + AES-256-GCM |
| 传输 | WebSocket (port 80, 无 TLS) |
| 逆向 | Ghidra 12.1.3 + pefile + capstone |
| 实现 | Python 3.12 + pycryptodome + cryptography |

---

## 关键数据

| 项目 | 值 |
|------|-----|
| 目标文件 | `xtun-windows.exe` (50MB, Go 1.25.0, PE64) |
| Go 模块 | `github.com/fmnx/cftun/backend` |
| API | `https://api.xtun.link` |
| 协议 | `cftun websocket v3` |
| payloadSecret | `replace-with-a-random-shared-secret` |
| Tunnel UUID | `01a093f1-0028-7ad6-98d2-54c12183dc79` |
| 节点数 | 19 |
| Endpoint IP | 173 |
| 验证结果 | 5/6 节点 101+HS+DATA 成功 |

---

## 学习路径建议

### 路径 A：完整逆向（推荐）

从 00 到 15，每步都做。约需 2-3 小时（Ghidra 分析占 1 小时）。

### 路径 B：快速实现

跳过 04-06（Ghidra 部分），直接从 07 开始用已知的函数地址和加密参数。

### 路径 C：只用结果

直接运行 `cftun_proxy_working.py`，不需要理解原理。

---

## 文件依赖

```
教学文档 (本目录)
    ↓ 参考
cftun_proxy_working.py    ← 最终代理脚本
cftun_nodes.json          ← 19 节点数据
xtun-windows.exe          ← 目标二进制
ghidra_project/           ← Ghidra 项目
```

---

## 注意事项

- 本教学仅供学习逆向工程技术
- 所有数据来自已完成的逆向分析项目
- 账号信息已在文档中脱敏处理
- 请遵守当地法律法规

---

*由逆向工程教学子代理生成*
