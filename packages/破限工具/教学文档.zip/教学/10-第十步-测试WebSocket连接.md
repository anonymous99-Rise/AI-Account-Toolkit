# 10 · 第十步 — 测试 WebSocket 连接

---

## 目标

构造 WebSocket 升级请求，测试不同 Host/Path/Header 组合，找到能成功的参数。

---

## 一、怎么构造 WebSocket 升级请求

```python
#!/usr/bin/env python3
"""ws_connect.py — 测试 WebSocket 连接"""
import socket, base64, os

def ws_upgrade(ip, port, host, path, extra_headers=None, timeout=10):
    """构造 WebSocket 升级请求"""
    sock = socket.create_connection((ip, port), timeout=timeout)
    sock.settimeout(timeout)

    ws_key = base64.b64encode(os.urandom(16)).decode()

    headers = [
        f"GET {path} HTTP/1.1",
        f"Host: {host}",
        "Upgrade: websocket",
        "Connection: Upgrade",
        f"Sec-WebSocket-Key: {ws_key}",
        "Sec-WebSocket-Version: 13",
        "Sec-WebSocket-Protocol: cftun websocket v3",
        "Origin: https://xtun.link",
        "User-Agent: DEV",
        "Content-Length: 0",
        "",
        ""
    ]

    if extra_headers:
        # 插入额外头
        insert_pos = len(headers) - 2
        for k, v in extra_headers.items():
            headers.insert(insert_pos, f"{k}: {v}")

    req = "\r\n".join(headers).encode()
    sock.sendall(req)

    response = b""
    while b"\r\n\r\n" not in response:
        chunk = sock.recv(4096)
        if not chunk:
            sock.close()
            return None, "Connection closed"
        response += chunk

    status_line = response.split(b"\r\n")[0].decode('utf-8', 'replace')
    sock.close()
    return status_line, response.decode('utf-8', 'replace')
```

---

## 二、测试不同 Host/Path/Header 组合

### 2.1 精确连接参数（已验证成功）

| 参数 | 值 | 说明 |
|------|-----|------|
| **Host** | 纯 IP 地址（不带端口） | 如 `8.148.254.224` |
| **Path** | `/{upstream}/e/{exit_server_ip}` | 如 `/hkg/e/27.0.232.13` |
| **User-Agent** | `DEV` | 大小写敏感 |
| **Port** | 80 | 无 TLS (ws://) |
| **Sec-WebSocket-Protocol** | `cftun websocket v3` | 可选 |
| **Origin** | `https://xtun.link` | 必须 |

### 2.2 测试脚本

```python
#!/usr/bin/env python3
"""test_ws_headers.py — 批量测试 WebSocket 连接"""

# 已知 endpoint IP（从 access_point 解密得到）
ENDPOINTS = [
    "8.148.254.224",
    "8.163.107.116",
    "8.134.192.242",
    "8.166.117.20",
]

# 测试组合
tests = [
    # (描述, ip, host, path, ua)
    ("正确: 纯IP + /hkg/e/ + DEV", "8.148.254.224", "8.148.254.224", "/hkg/e/27.0.232.13", "DEV"),
    ("错误: 域名Host", "8.148.254.224", "as6185.net", "/hkg/e/27.0.232.13", "DEV"),
    ("错误: Host带端口", "8.148.254.224", "8.148.254.224:80", "/hkg/e/27.0.232.13", "DEV"),
    ("错误: UA≠DEV", "8.148.254.224", "8.148.254.224", "/hkg/e/27.0.232.13", "Mozilla/5.0"),
    ("错误: Path带cf_前缀", "8.148.254.224", "8.148.254.224", "/cf_hkg/e/27.0.232.13", "DEV"),
    ("错误: Path=/", "8.148.254.224", "8.148.254.224", "/", "DEV"),
]

for desc, ip, host, path, ua in tests:
    status, resp = ws_upgrade(ip, 80, host, path,
                              extra_headers={'User-Agent': ua})
    result = "✅" if status and "101" in status else "❌"
    print(f"{result} {desc}: {status}")
```

### 2.3 预期结果

```
✅ 正确: 纯IP + /hkg/e/ + DEV: HTTP/1.1 101 Switching Protocols
❌ 错误: 域名Host: HTTP/1.1 403 Forbidden
❌ 错误: Host带端口: (timeout / connection reset)
❌ 错误: UA≠DEV: (444 silent disconnect)
❌ 错误: Path带cf_前缀: HTTP/1.1 404 Not Found
❌ 错误: Path=/: HTTP/1.1 404 Not Found
```

---

## 三、怎么判断成功

成功的标志是 **`101 Switching Protocols`**：

```http
HTTP/1.1 101 Switching Protocols
Upgrade: websocket
Connection: Upgrade
Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=
```

任何其他状态码都是失败：

| 状态码 | 原因 |
|--------|------|
| 101 | ✅ 成功 |
| 403 | Beaver WAF 拦截（域名 Host） |
| 404 | 路径错误 |
| 444 | nginx 静默断开（UA 不对） |
| timeout | 连接被拒绝或重置 |

---

## 四、怎么识别 WAF

### 4.1 WAF 架构

```
客户端 → Beaver WAF → nginx/1.31.4 → WebSocket 后端
```

### 4.2 三层过滤

| 层 | 检查什么 | 失败结果 |
|----|----------|----------|
| **Beaver WAF** | Host 头是域名 → ICP 未备案 | 403 Forbidden |
| **nginx 1.31.4** | User-Agent ≠ "DEV" | 444 静默断开 |
| **WebSocket 后端** | Path 格式不对 | 404 Not Found |

### 4.3 识别方法

```python
# 测试 WAF 响应
status, resp = ws_upgrade("8.148.254.224", 80, "as6185.net", "/hkg/e/27.0.232.13")

if "403" in status:
    print("Beaver WAF 拦截 (域名 Host)")
    # 检查响应体是否有 "ICP" 字样
    if "ICP" in resp or "beaver" in resp.lower():
        print("确认: Beaver WAF")

status, resp = ws_upgrade("8.148.254.224", 80, "8.148.254.224",
                          "/hkg/e/27.0.232.13",
                          extra_headers={'User-Agent': 'Mozilla/5.0'})
if not status or "444" in status:
    print("nginx 静默断开 (UA 不对)")
```

---

## 五、细节：为什么之前 186 次失败

### 失败原因分析

| # | 错误 | 正确值 | 原因 |
|---|------|--------|------|
| 1 | Path 带 cf_ 前缀 `/cf_hkg/e/...` | `/hkg/e/...` | isArgo=false 时不加 cf_ 前缀 |
| 2 | Host 带端口 `8.148.254.224:80` | `8.148.254.224` | 纯 IP 不带端口 |
| 3 | 用域名 Host | 用纯 IP Host | 域名触发 Beaver WAF 403 |
| 4 | User-Agent 不精确 | `DEV` | nginx 检查 UA 精确匹配 |

### Ghidra 反编译确认

| 函数 | 地址 | 确认内容 |
|------|------|----------|
| `implicitWebsocketRouteUpstream` | `0x14034f3a0` | isArgo=false 时不加 cf_ 前缀 |
| `connectWithPurpose` | `0x14034afc0` | UA=DEV 在初始 HTTP 请求就设置 |
| `NewWebsocket` | `0x140348120` | gorilla Dialer Subprotocols=nil |

---

## 六、验证成功的 IP

经过测试，这些 endpoint IP 全部返回 101：

| IP | 状态 | 关联节点 |
|----|------|----------|
| `8.148.254.224` | ✅ 101 | 香港/曼谷/河内 |
| `8.163.107.116` | ✅ 101 | 香港/曼谷/河内 |
| `8.134.192.242` | ✅ 101 | 香港/曼谷/河内 |
| `8.166.117.20` | ✅ 101 | 香港/曼谷/河内 |

---

## 七、关键发现总结

走完这一步你应该有：

- ✅ WebSocket 连接参数全部确认
- ✅ Host = 纯 IP（不带端口）
- ✅ Path = `/{upstream}/e/{exit_server_ip}`（无 cf_ 前缀）
- ✅ UA = `DEV`（大小写敏感）
- ✅ 端口 80，无 TLS
- ✅ WAF 架构理解（Beaver → nginx → backend）
- ✅ 4 个 IP 返回 101 成功

---

**下一步**：`11-第十一步-实现协议握手.md`
