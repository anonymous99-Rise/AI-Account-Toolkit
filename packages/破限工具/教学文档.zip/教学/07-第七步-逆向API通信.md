# 07 · 第七步 — 逆向 API 通信

---

## 目标

分析 xTun 的 API 通信，找到 API base URL、登录接口，用 Python 模拟登录。

---

## 一、怎么找到 API base URL

### 搜索字符串

```bash
strings xtun-windows.exe | grep -E "xtun\.link|xtun\.dev|api\." | sort -u
```

### 预期结果

```
api.xtun.link
xtun.link
downloads.xtun.dev
```

### 服务器列表

| 服务 | URL | 用途 |
|------|-----|------|
| API | `https://api.xtun.link` | 主 API 服务器 |
| Web | `https://xtun.link` | 前端网站 |
| 下载 | `https://downloads.xtun.dev` | 客户端下载 |
| 网络画像 | `203.196.8.69:8800` 等 | 网络探测 |

---

## 二、怎么找到登录接口

### 搜索 API 路径字符串

```bash
strings xtun-windows.exe | grep -E "/v1/|/auth/|/login|/node/|/tunnel/" | sort -u
```

### 预期结果

```
/v1/auth/login
/v1/auth/register
/v1/auth/reset
/v1/common/send_code
/v1/common/site/config
/v1/public/node/summary
/v1/public/node/catalog.dat
/v1/public/tunnel/info
/v1/public/user/info
/v1/public/user/subscribe
/v1/public/subscribe/list
/v1/common/network-profile
```

### API 端点分类

| 端点 | 方法 | 说明 | 需登录？ |
|------|------|------|----------|
| `/v1/auth/login` | POST | 登录 | ❌ |
| `/v1/auth/register` | POST | 注册 | ❌ |
| `/v1/auth/reset` | POST | 密码重置 | ❌ |
| `/v1/common/send_code` | POST | 发送验证码 | ❌ |
| `/v1/common/site/config` | GET | 站点配置 | ❌ |
| `/v1/public/node/summary` | GET | 节点摘要 | ✅ |
| `/v1/public/node/catalog.dat` | GET | 节点目录 | ✅ |
| `/v1/public/tunnel/info` | GET | 隧道信息 | ✅ |
| `/v1/public/user/info` | GET | 用户信息 | ✅ |
| `/v1/public/user/subscribe` | GET | 订阅状态 | ✅ |
| `/v1/public/subscribe/list` | GET | 套餐列表 | ✅ |
| `/v1/common/network-profile` | GET | 网络画像 | ❌ |

---

## 三、认证方式

### 细节：Authorization header 无 Bearer 前缀

xTun 的认证头是**裸 JWT**，不加 `Bearer ` 前缀：

```
Authorization: <JWT token>
```

不是：
```
Authorization: Bearer <JWT token>    ← 错误！
```

这是逆向发现的关键细节。标准 OAuth2 用 `Bearer `，xTun 不用。

### 必须的请求头

| 头 | 值 | 说明 |
|----|-----|------|
| `Authorization` | `<JWT>` | 裸 token，无 Bearer |
| `Origin` | `https://xtun.link` | 必须带 |
| `Referer` | `https://xtun.link/` | 必须带 |
| `Content-Type` | `application/json` | POST 请求 |
| `User-Agent` | `Mozilla/5.0` 或任意 | 服务器不检查 |

---

## 四、用 Python 模拟登录

```python
#!/usr/bin/env python3
"""login_api.py — 模拟 xTun 登录"""
import socket, ssl, json

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def raw_https(method, path, extra_headers=None, json_body=None):
    """裸 HTTPS 请求（不依赖 requests 库）"""
    s = socket.create_connection(('api.xtun.link', 443), timeout=20)
    ss = ctx.wrap_socket(s, server_hostname='api.xtun.link')

    parts = [f'{method} {path} HTTP/1.1', 'Host: api.xtun.link']
    if extra_headers:
        for k, v in extra_headers.items():
            parts.append(f'{k}: {v}')
    parts.append('User-Agent: Mozilla/5.0')
    parts.append('Connection: close')

    payload = b''
    if json_body is not None:
        payload = json.dumps(json_body).encode()
        parts.append(f'Content-Length: {len(payload)}')
        parts.append('Content-Type: application/json')

    parts.extend(['', ''])
    req = '\r\n'.join(parts).encode() + payload
    ss.send(req)

    resp = b''
    while True:
        try:
            c = ss.recv(65536)
            if not c: break
            resp += c
        except: break
    ss.close()

    idx = resp.index(b'\r\n\r\n')
    return resp[:idx].decode('utf-8', 'replace'), resp[idx+4:]

# === 登录 ===
h, b = raw_https('POST', '/v1/auth/login',
    extra_headers={'Origin': 'https://xtun.link'},
    json_body={
        'email': 'anchastonmicarp1997@outlook.com',
        'password': 'Sagamoto%3844'
    })

result = json.loads(b)
print(f"Status: {result.get('code')}")
print(f"Message: {result.get('msg')}")

if result.get('code') == 200:
    token = result['data']['token']
    tunnel_uuid = result['data'].get('tunnel_uuid', '')
    print(f"Token: {token[:50]}...")
    print(f"Tunnel UUID: {tunnel_uuid}")

    # 保存 token
    with open('token.txt', 'w') as f:
        f.write(token)
    print("Token saved to token.txt")
```

### 预期输出

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIs...",
    "tunnel_uuid": "01a093f1-0028-7ad6-98d2-54c12183dc79",
    "user_id": 9
  }
}
```

---

## 五、获取节点配置

登录后，请求节点列表。**需要带 X25519 公钥头**：

```python
import base64
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from cryptography.hazmat.primitives import serialization

# 1. 生成 X25519 密钥对
client_priv = X25519PrivateKey.generate()
client_pub = client_priv.public_key().public_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PublicFormat.Raw
)
pub_b64 = base64.urlsafe_b64encode(client_pub).rstrip(b'=').decode()

# 2. 请求节点列表
h, b = raw_https('GET', '/v1/public/node/list',
    extra_headers={
        'Authorization': token,           # 裸 JWT，无 Bearer
        'Origin': 'https://xtun.link',
        'X-Cftun-Config-Key': pub_b64,    # X25519 公钥
    })

config_response = json.loads(b)
print(f"Algorithm: {config_response.get('algorithm')}")
print(f"Version: {config_response.get('version')}")
# 服务器返回: {version, algorithm, server_public_key, salt, nonce, ciphertext}
```

---

## 六、API 请求流程图

```
1. POST /v1/auth/login
   body: {email, password}
   → 返回 {token, tunnel_uuid}

2. 生成 X25519 密钥对 (client_priv, client_pub)

3. GET /v1/public/node/list
   headers: Authorization=<token>, X-Cftun-Config-Key=base64url(client_pub)
   → 返回加密的 {server_public_key, salt, nonce, ciphertext}

4. 解密配置响应 (Layer 1)
   → 得到 {data: {list: [{nodes: [19个节点]}]}}

5. 对每个节点解密 access_point (Layer 2)
   → 得到真实出口 IP 列表
```

---

## 七、细节：Token 存储位置

xTun 客户端把 token 存在：

| 平台 | 位置 |
|------|------|
| Windows | `C:\Users\<user>\AppData\Local\xTun\user.json` |
| Android | SharedPreferences / `cftun.authorization` |
| Web | `localStorage["cftun.authorization"]` |

---

## 八、关键发现总结

走完这一步你应该有：

- ✅ API base URL: `https://api.xtun.link`
- ✅ 登录接口: `POST /v1/auth/login`
- ✅ 认证方式: 裸 JWT（无 Bearer 前缀）
- ✅ 必须头: Authorization + Origin
- ✅ 节点列表接口: `GET /v1/public/node/list` + `X-Cftun-Config-Key` 头
- ✅ Python 登录脚本可用
- ✅ Token 和 tunnel_uuid 已获取

---

**下一步**：`08-第八步-解密节点配置.md`
