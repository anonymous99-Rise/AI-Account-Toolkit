# 04 · 第四步 — Ghidra 导入分析

---

## 目标

用 Ghidra Headless 模式导入 `xtun-windows.exe`，自动分析，生成项目。

---

## 一、为什么用 Headless 模式

Go 二进制 50MB，GUI 模式分析会卡顿。Headless 模式：
- 命令行启动，不打开 GUI
- 自动导入 + 自动分析
- 可以跑脚本批量反编译
- 分析完成后再用 GUI 打开看结果

---

## 二、Headless 导入命令

```bash
# 完整命令
E:\nixianggongju\Tools\ghidra_12.1.3_PUBLIC\support\analyzeHeadless.bat \
  "C:\ghidra_work\proj" \
  xtun_proj \
  -import "E:\逆向\XTun\xtun-windows.exe" \
  -overwrite \
  -postScript "E:\逆向\XTun\ghidra_scripts\ExportFunctions.java" \
  -scriptPath "E:\逆向\XTun\ghidra_scripts"
```

### 参数解释

| 参数 | 含义 |
|------|------|
| `C:\ghidra_work\proj` | 项目目录（Ghidra 会创建） |
| `xtun_proj` | 项目名 |
| `-import` | 要导入的二进制文件 |
| `-overwrite` | 如果项目已存在，覆盖（否则会报错） |
| `-postScript` | 导入后自动运行的脚本 |
| `-scriptPath` | 脚本搜索路径 |

---

## 三、导入后怎么确认成功

```bash
# 检查项目目录
ls "C:\ghidra_work\proj\xtun_proj"
# 应该有 .gpr 文件和 .rep 目录

# 检查日志
cat "C:\ghidra_work\proj\xtun_proj\xtun.exe.log"
# 最后一行应该有 "Analysis succeeded" 或类似
```

---

## 四、分析要等多久

**Go 二进制分析很慢。** 50MB 的 Go PE：

| 阶段 | 耗时 |
|------|------|
| 导入 | ~2 分钟 |
| 自动分析 | **30-60 分钟**（Go 符号多） |
| 脚本反编译 | ~10-20 分钟 |

总计约 **1-1.5 小时**。耐心等，不要中断。

### 分析在做什么

Ghidra 分析 Go 二进制时会：
1. 识别所有函数（Go 有几万个函数）
2. 反汇编 .text 节区
3. 建立交叉引用
4. 恢复类型信息（Go 的 `golang.org/x/debug/elf` 有 DWARF 调试信息）
5. 识别字符串引用

---

## 五、用 GUI 打开分析完成的项目

```bash
# 启动 Ghidra GUI
E:\nixianggongju\Tools\ghidra_12.1.3_PUBLIC\ghidraRun.bat
```

在 GUI 中：
1. `File → Open Project → C:\ghidra_work\proj\xtun_proj`
2. 双击 `xtun.exe`
3. 等待 GUI 加载（~1 分钟）
4. 左侧 `Symbol Tree` 可以看到所有函数

---

## 六、Ghidra 反编译脚本

分析完成后，用脚本批量反编译关键函数：

```java
// ghidra_scripts/DecompileFunctions.java
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;
import java.io.FileWriter;

public class DecompileFunctions extends GhidraScript {
    @Override
    public void run() throws Exception {
        DecompInterface decomp = new DecompInterface();
        decomp.openProgram(currentProgram);

        FileWriter fw = new FileWriter("E:\\逆向\\XTun\\decompiled_functions.txt");

        // 搜索包含关键词的函数
        String[] keywords = {"decrypt", "AccessPoint", "Websocket",
                             "PayloadSecret", "ConfigResponse", "HKDF",
                             "ChaCha20", "AESGCM", "X25519"};

        FunctionIterator funcs = currentProgram.getFunctionManager().getFunctions(true);
        while (funcs.hasNext()) {
            Function func = funcs.next();
            String name = func.getName();
            for (String kw : keywords) {
                if (name.contains(kw)) {
                    DecompileResults res = decomp.decompileFunction(func, 60, monitor);
                    if (res.decompileCompleted()) {
                        fw.write("// === " + name + " @ " +
                                func.getEntryPoint() + " ===\n");
                        fw.write(res.getDecompiledFunction().getC() + "\n\n");
                    }
                    break;
                }
            }
        }
        fw.close();
        decomp.dispose();
        println("Decompilation complete!");
    }
}
```

### 运行反编译脚本

```bash
E:\nixianggongju\Tools\ghidra_12.1.3_PUBLIC\support\analyzeHeadless.bat \
  "C:\ghidra_work\proj" \
  xtun_proj \
  -process "xtun.exe" \
  -noanalysis \
  -postScript DecompileFunctions.java \
  -scriptPath "E:\逆向\XTun\ghidra_scripts"
```

注意：`-process` 而不是 `-import`，`-noanalysis` 跳过分析（已完成）。

---

## 七、细节：Go 二进制的特殊处理

Go 编译器生成的 PE 有一些特殊性：

1. **函数名包含包路径**：`github.com/fmnx/cftun/backend/dialer.decryptAccessPoint`
2. **没有标准 PE 导出表**：Go 用自己的符号表
3. **字符串没有 null 终止**：Go 字符串是 (指针, 长度) 对
4. **栈管理不同**：Go 用连续栈，Ghidra 可能误判

Ghidra 12+ 对 Go 有较好支持，能自动识别 Go 函数名和类型。

---

## 八、关键发现总结

走完这一步你应该有：

- ✅ Ghidra 项目 `C:\ghidra_work\proj\xtun_proj`
- ✅ 分析完成（等了约 1 小时）
- ✅ `decompiled_functions.txt`（反编译结果，约 561KB）
- ✅ 可以用 GUI 浏览函数

---

**下一步**：`05-第五步-定位关键函数.md`
